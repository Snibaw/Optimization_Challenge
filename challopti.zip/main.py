from file_import import *

def main():
    data = readFile("cs4.txt")
    print(data.options[0].name)
    return

if __name__ == '__main__':
    main()