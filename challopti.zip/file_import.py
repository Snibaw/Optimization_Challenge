class Option:
    def __init__(self, i, ratio1, ratio2, w, name):
        self.index = i
        self.ratio_n = ratio1
        self.ratio_p = ratio2
        self.weight = w
        self.name = name

class Vehicle:
    def __init__(self, i, opt):
        self.index = i
        self.options = opt # An array of Options

class Data:
    def __init__(self, o_number, options_array, v_number, vehicles_array):
        self.options_number = o_number
        self.options = options_array
        self.vehicles_number = v_number
        self. vehicles = vehicles_array

def readFile(file_name):
    f = open(file_name,"r")
    line = f.readline()
    option_number = int(line[8:])
    line = f.readline()
    vehicle_number = int(line[10:])
    
    for _ in range(3):
        line = f.readline()
    
    # Création des options
    options_array = []
    for i in range(option_number):
        array = line.split()
        opt = Option(i, array[0], array[1], array[2], array[3])
        options_array.append(opt)
        line = f.readline()

    for _ in range(2):
        line = f.readline()

    # Création des véhicules
    vehicles_array = []
    for i in range(vehicle_number): # Les véhicules vont de 0 à N-1 et non pas de 1 à N
        array = line.split()
        bool_array = [ bool(int(n)) for n in array[1:] ]
        v = Vehicle(i, bool_array)
        vehicles_array.append(v)
        line = f.readline()

    return Data(option_number, options_array, vehicle_number, vehicles_array)